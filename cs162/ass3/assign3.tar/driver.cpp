//driver.cpp

#include <iostream>

#include "animal.h"
#include "zoo.h"
#include "tiger.h"
#include "sealion.h"
#include "bear.h"

using namespace std;

int main() {
	Zoo zoo;
	
	zoo.setup_game();
	while(!zoo.out_o_money()){
		zoo.user_turn();
	}

//	zoo.test();

	//test
//	Tiger tiger;	
//	tiger.print_tiger();

	return 0;
}
