//animal.cpp

#include "animal.h"
#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;


Animal::~Animal(){
//	cout << "Animal Destructor Called" << endl;
}
	
Animal::Animal(){
	name = "animal";
	
	//cout << "Animal Created" << endl;
}

Animal::Animal(const Animal& a){
//	cout << "animal copy constructor" << endl;
}
/*
void Animal::operator++ (int a){
	int size = zoo.get_size() + 1;
	Animal* temp = new Animal[size];
	for(int i = 0; i < size-1; i++){
		temp[i] = a[i];
	}
	delete [] a;
	a = temp;

	return temp;
}
*/



void Animal::set_animal_name(string s){
	name = s;
}

void Animal::set_age(int s){
	age = s;
}
void Animal::set_cost(int s){
	cost = s;
}
void Animal::set_baby(int s){
	baby = s;
}
void Animal::set_food_cost(int s){
	food_cost = s;
}

void Animal::set_revenue(int s){
	revenue = s;
}

string Animal::get_animal_name(){
	return "stuff";
}

int Animal::get_age(){
	return age;
}

int Animal::get_cost(){
	return cost;
}

int Animal::get_baby(){
	return baby;
}

int Animal::get_food_cost(){
	return food_cost;
}

int Animal::get_revenue(){
	return revenue;
}

void Animal::increase_age(){

}

void Animal::random_event(){
	srand(time(NULL));

	int choice = 0; 
	choice = rand() % 3;

	if(choice == 0)	{
		//nothing
	}
	if(choice == 1)	{
		int rev_boost = 0;
		rev_boost = ((rand() % 251) + 150);
		revenue = revenue + rev_boost;
	}
	if(choice == 2)	{
		//new babies
	}
	if(choice == 3)	{
		//sickness
	}
}

void Animal::buy_animal(int species, int num){
	if(species == 0){
	}	
	else if(species == 1){
//		Tiger t;
	}	
	else if(species == 2){
//		Bear b;
	}	
	else if(species == 3){
//		Sealion s;
	}
}

void Animal::feed_animal(){
	//multiply costs of animals
}
