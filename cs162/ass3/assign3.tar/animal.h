//animal.h
#ifndef ANIMAL
#define ANIMAL

#include <iostream>
#include <cstdlib>

//#include "tiger.h"
//#include "bear.h"
//#include "sealion.h"

using namespace std;

class Animal{
	string name;
	int age;
	int cost;
	int baby;
	int food_cost;
	int revenue;
	
public:
	Animal();
	~Animal();
	Animal(const Animal&);
//	void operator++ (int); 
		
	void set_animal_name(string);
	void set_age(int);
	void set_cost(int);	
	void set_baby(int);	
	void set_food_cost(int);	
	void set_revenue(int);	

	string get_animal_name();
	int get_age();
	int get_cost();	
	int get_baby();	
	int get_food_cost();	
	int get_revenue();	

	void increase_age();
	void random_event();
	
	void buy_animal(int s, int n);
	void feed_animal();
};

#endif
