//Driver.cpp - Driver File

#include <iostream>
#include <cstdlib>

#include "card.h"
#include "deck.h"
#include "game.h"
#include "hand.h"
#include "player.h"

using namespace std;

int main(){
	Game gm;


	gm.setup_game();
	gm.deal_cards();
	gm.print_game();

	do{
	gm.user_turn();
	gm.com_turn();	
	gm.print_game();
	}while(gm.winner() == false);

	return 0;
}
