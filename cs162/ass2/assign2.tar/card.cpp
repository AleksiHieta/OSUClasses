// Card.cpp - Implementation File

#include "card.h"
#include <iostream>
#include <cstdlib>

using namespace std;

Card::Card(){
	
}

Card::~Card(){
	//delete [] rank;
	//delete [] suit;
}

Card::Card(const Card& c){
	//size = c.size;
	
}

int Card::get_suit(){
	
	return suit;
}	

int Card::get_rank(){
	return rank;
}

void Card::set_card(int n, int s){
	rank = n;
	suit = s;
}

void Card::print_card(){
	if(rank == 0){
	}
	else if(rank == 1){
		cout << "A";
	}
	else if(rank == 11){
		cout << "J";
	}
	else if(rank == 12){
		cout << "Q";
	}
	else if(rank == 13){
		cout << "K";
	}
	else{
		cout << rank;
	}
	
	if(suit == 0){
	} 
	else if(suit == 1){
		cout << " Hearts" << endl;
	} 
	else if(suit == 2){
		cout << " Diamonds" << endl;
	} 
	else if(suit == 3){
		cout << " Clubs" << endl;
	} 
	else if(suit == 4){
		cout << " Spades" << endl;
	} 
}

